import os
maps = os.listdir("edge")

for name in maps:
    print()
    print(f"{name}")
    os.system(f"python3 main.py edge/{name}")
