import sys

from MapParser import MapParser
from PathFinder import PathFinder
from Simulation import Simulation


def main() -> None:
    if len(sys.argv) != 2:
        print("Usage: python3 main.py <map_file>")
        return

    filename = sys.argv[1]

    try:
        nb_drones, start_hub, end_hub, zones, graph, connections = (
            MapParser.parse_file(filename)
        )

        paths = PathFinder.find_paths(
            zones,
            graph,
            start_hub,
            end_hub,
        )

        simulation = Simulation(
            nb_drones,
            paths,
            zones,
            connections,
            start_hub,
            end_hub,
        )

        simulation.run()
        print(f"Turns: {simulation.turn}")

    except FileNotFoundError:
        print(f"Error: file not found: {filename}")
    except ValueError as error:
        print(f"Error: {error}")


if __name__ == "__main__":
    main()


# python -m venv flyin
# source flyin/bin/activate

# import os
# maps = os.listdir("maps")

# for name in maps:
#     print(f"{name}")
#     os.system(f"python3 main.py maps/{name}")

# import os
# maps = os.listdir("edge")

# for name in maps:
#     print()
#     print(f"{name}")
#     os.system(f"python3 main.py edge/{name}")

# a = [(10, "silva"), (5, "maria")]

# heappush(a,(0, "aksel"))
# heappush(a,(1, "alex"))


# print(a)
# x = heappop(a)

# print(x)
# print(a)
